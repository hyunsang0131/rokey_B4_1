# 계산 모듈 검증:  python3 -m pytest test/test_bed_math.py -v
import itertools
import math
import random

import pytest

from bed_inspect import bed_math as bm

H = [25.0, 30.0, 35.0]
ROWS, COLS = 2, 3
PC, PR = 100.0, 120.0


def curve(k, z_surf, f_to=20.0, step=0.5, noise=0.0, toe=0.0, seed=0):
    """가짜 누르기 곡선. toe: 접촉 초반에 힘이 덜 나오는 구간(mm)."""
    rnd = random.Random(seed)
    out, z = [], z_surf + 5.0
    while True:
        pen = z_surf - z
        f = 0.0 if pen <= 0 else k * pen if pen > toe else k * pen * pen / toe if toe else k * pen
        f += rnd.gauss(0, noise)
        out.append((z, f))
        if f >= f_to:
            return out
        z -= step


# ── 강성 ──
def test_stiffness_exact():
    r = bm.fit_stiffness(curve(2.0, 100.0), f_min=5.0)
    assert r['k'] == pytest.approx(2.0, abs=1e-9)
    assert r['z_surf'] == pytest.approx(100.0, abs=1e-9)
    assert r['r2'] == pytest.approx(1.0)


@pytest.mark.parametrize('k', [0.8, 1.5, 2.0, 3.5])
def test_stiffness_with_noise(k):
    """힘 노이즈 0.3N 에서 강성 오차 5% 이내, 표면 높이 오차 0.5mm 이내 (100번 반복)."""
    errs, zerrs = [], []
    for seed in range(100):
        r = bm.fit_stiffness(curve(k, 100.0, noise=0.3, seed=seed), f_min=5.0)
        errs.append(abs(r['k'] - k) / k)
        zerrs.append(abs(r['z_surf'] - 100.0))
    assert sorted(errs)[94] < 0.05
    assert sorted(zerrs)[94] < 0.5


def test_stiffness_too_few_points():
    assert bm.fit_stiffness([(100, 0), (99.5, 6), (99, 7)], f_min=5.0) is None
    assert bm.fit_stiffness([], f_min=5.0) is None


# ── 판정 ──
def blocks(ks, hs=None):
    hs = hs or [30.0] * len(ks)
    return [{'slot': i, 'height': h, 'k': k, 'error': None} for i, (k, h) in enumerate(zip(ks, hs))]


def test_judge_median_same_height():
    b = bm.judge(blocks([2.0, 2.05, 1.95, 2.0, 1.2, 2.4]), {}, 0.15, 0.30)
    assert [x['grade'] for x in b] == ['ok', 'ok', 'ok', 'ok', 'fail', 'warn']
    assert b[4]['dev'] == pytest.approx(-0.4)
    assert b[0]['ref_src'] == 'median'


def test_judge_mixed_heights_no_false_alarm():
    """높이가 달라 강성이 다른 것은 불량이 아니다 (k × 높이 로 비교)."""
    hs = [25.0, 30.0, 35.0, 25.0, 30.0, 35.0]
    ks = [60.0 / h for h in hs]
    b = bm.judge(blocks(ks, hs), {}, 0.15, 0.30)
    assert all(x['grade'] == 'ok' for x in b)
    ks[2] *= 0.6
    b = bm.judge(blocks(ks, hs), {}, 0.15, 0.30)
    assert [x['grade'] for x in b] == ['ok', 'ok', 'fail', 'ok', 'ok', 'ok']


def test_judge_calib_catches_all_bad():
    """6개가 전부 나빠져도 기준값이 있으면 잡는다 (중앙값만으로는 못 잡음)."""
    ks = [1.2] * 6
    assert all(x['grade'] == 'ok' for x in bm.judge(blocks(ks), {}, 0.15, 0.30))
    assert all(x['grade'] == 'fail' for x in bm.judge(blocks(ks), {'30.0': 2.0}, 0.15, 0.30))


def test_judge_errors():
    b = blocks([2.0, None, None, 2.0, 2.0, 2.0])
    b[1]['error'] = 'no_contact'
    b[2]['error'] = 'bad_fit'
    b = bm.judge(b, {}, 0.15, 0.30)
    assert b[1]['grade'] == 'fail' and b[2]['grade'] == 'nodata'


def test_make_calib():
    c = bm.make_calib(blocks([2.0, 2.2, 2.4, 1.0, 1.1, 1.2], [30, 30, 30, 35, 35, 35]), {'25.0': 3.0})
    assert c == {'25.0': 3.0, '30.0': 2.2, '35.0': 1.1}


# ── 기울기 측정 ──
def grid_xy(x0=500.0, y0=-100.0, rot_deg=0.0):
    c, s = math.cos(math.radians(rot_deg)), math.sin(math.radians(rot_deg))
    return [(x0 + c * col * PC - s * row * PR, y0 + s * col * PC + c * row * PR)
            for row in range(ROWS) for col in range(COLS)]


@pytest.mark.parametrize('rot', [0.0, 37.0, 90.0, 180.0, -120.0])
def test_measured_tilt_any_bed_direction(rot):
    """침대가 로봇 기준으로 어느 방향으로 놓여 있어도 같은 기울기가 나와야 한다."""
    xy = grid_xy(rot_deg=rot)
    z = [80.0 + h for h in [25, 30, 35, 25, 30, 35]]          # 열 방향으로 5mm 씩 높아짐
    t = bm.measured_tilt(xy, z, ROWS, COLS)
    assert t['col_deg'] == pytest.approx(math.degrees(math.atan(5 / PC)), abs=1e-6)
    assert t['row_deg'] == pytest.approx(0.0, abs=1e-6)
    z = [80.0 + h for h in [25, 25, 25, 35, 35, 35]]          # 행 방향으로 10mm
    t = bm.measured_tilt(xy, z, ROWS, COLS)
    assert t['row_deg'] == pytest.approx(math.degrees(math.atan(10 / PR)), abs=1e-6)
    assert t['col_deg'] == pytest.approx(0.0, abs=1e-6)


def test_measured_tilt_missing_points():
    xy = grid_xy()
    z = [105, None, 115, 105, 110, None]
    t = bm.measured_tilt(xy, z, ROWS, COLS)
    assert t['n'] == 4 and t['col_deg'] == pytest.approx(math.degrees(math.atan(5 / PC)), abs=1e-6)
    assert bm.measured_tilt(xy, [1, None, None, None, None, 2], ROWS, COLS) is None


# ── 기울기 계획 ──
FULL_RACK = [25.0] * 6 + [35.0] * 6 + [30.0] * 6 + [None]


def plan(tc, tr, bed=None, rack=None, **kw):
    return bm.plan_tilt(tc, tr, bed or [30.0] * 6, FULL_RACK if rack is None else rack,
                        H, ROWS, COLS, PC, PR, **kw)


def test_achievable_angles():
    c = bm.tilt_candidates([30.0] * 6, FULL_RACK, H, ROWS, COLS, PC, PR)
    a = bm.achievable_angles(c)
    t1 = round(math.degrees(math.atan(5 / PC)), 1)
    r1 = round(math.degrees(math.atan(5 / PR)), 1)
    r2 = round(math.degrees(math.atan(10 / PR)), 1)
    assert a['col'] == [-t1, 0.0, t1]
    assert a['row'] == [-r2, -r1, 0.0, r1, r2]
    assert all(x['rms'] <= 0.5 for x in c)


def test_plan_tilt_picks_nearest():
    t1 = math.degrees(math.atan(5 / PC))            # 2.86도
    p = plan(3.0, 0.0)
    assert p['heights'] == [25, 30, 35, 25, 30, 35] and p['col_deg'] == pytest.approx(t1)
    p = plan(-10.0, 0.0)                            # 만들 수 없는 큰 각도 → 가장 가까운 것
    assert p['heights'] == [35, 30, 25, 35, 30, 25]
    p = plan(1.0, 0.0)                              # 0 에 더 가깝다 → 그대로
    assert p['heights'] == [30.0] * 6 and p['moves'] == []
    p = plan(1.6, 0.0)                              # 2.86 에 더 가깝다
    assert p['heights'] == [25, 30, 35, 25, 30, 35]
    p = plan(0.0, 4.0)                              # 행 방향: 2.39 / 4.76 중 4.76
    assert p['heights'] == [25, 25, 25, 35, 35, 35]
    p = plan(0.0, -2.0)                             # 행 방향 -2.39: 교체 수가 적은 조합
    assert p['row_deg'] == pytest.approx(-math.degrees(math.atan(5 / PR)))
    assert p['changed'] == 3


def test_plan_tilt_is_global_optimum():
    """고른 배치보다 목표에 더 가까운 배치가 하나도 없는지 전수 확인."""
    rnd = random.Random(1)
    for _ in range(60):
        tc, tr = rnd.uniform(-6, 6), rnd.choice([0.0, rnd.uniform(-6, 6)])
        p = plan(tc, tr)
        best = min(math.hypot(c['col_deg'] - tc, c['row_deg'] - tr)
                   for c in bm.tilt_candidates([30.0] * 6, FULL_RACK, H, ROWS, COLS, PC, PR))
        assert p['err'] == pytest.approx(best, abs=1e-3)


def test_plan_tilt_respects_stock():
    """35mm 블록이 1개뿐이면 열 방향 기울기(35mm 2개 필요)는 못 만든다 → 가능한 것 중 가장 가까운 것."""
    rack = [25.0, 25.0, 25.0, 35.0, None]
    p = plan(3.0, 0.0, rack=rack)
    assert p['heights'].count(35.0) <= 1
    assert p['heights'].count(25.0) <= 3
    assert abs(p['col_deg']) < 0.01                 # 열 방향은 불가 → 0도(평평)


def test_plan_tilt_step_option():
    p = plan(1.4, 0.0, allow_step=True)             # 계단 허용: 2.86 과 0 사이 각도를 만든다
    assert 0.5 < p['col_deg'] < 2.5 and p['rms'] > 0.5


# ── 이동 순서 ──
def simulate(bed, rack, moves):
    """이동을 하나씩 따라가며 물리적으로 가능한지 확인."""
    bed, rack = list(bed), list(rack)
    for m in moves:
        (sk, si), (dk, di) = m['src'], m['dst']
        src = bed if sk == 'bed' else rack
        assert src[si] is not None and src[si] == m['h'], '없는 블록을 집음'
        if dk != 'discard':
            dst = bed if dk == 'bed' else rack
            assert dst[di] is None, '블록이 있는 자리에 놓음'
        bm.apply_move(bed, rack, m)
    return bed, rack


def test_plan_moves_all_configs_with_one_empty_rack_slot():
    """현재/목표 배치 조합을 무작위로 3000개 시험: 빈 자리 1개로 항상 성공하고 블록이 사라지지 않는다."""
    rnd = random.Random(7)
    combos = list(itertools.product(H, repeat=6))
    for _ in range(3000):
        bed, target = list(rnd.choice(combos)), list(rnd.choice(combos))
        rack = [25.0] * 6 + [30.0] * 6 + [35.0] * 6 + [None]
        rnd.shuffle(rack)
        moves = bm.plan_moves(bed, rack, target)
        end_bed, end_rack = simulate(bed, rack, moves)
        assert end_bed == target
        assert sorted(x for x in end_bed + end_rack if x) == sorted(x for x in bed + rack if x)
        changed = sum(a != b for a, b in zip(bed, target))
        assert len(moves) <= 2 * changed


def test_plan_moves_reverse_tilt_minimal_stock():
    """예비 블록 없이(보관대 빈 자리 1개) 기울기 방향 뒤집기: 침대 안에서 직접 옮긴다."""
    bed, target = [25, 30, 35, 25, 30, 35], [35, 30, 25, 35, 30, 25]
    moves = bm.plan_moves(bed, [None], target)
    assert simulate(bed, [None], moves)[0] == target
    assert len(moves) == 6


def test_plan_moves_errors():
    with pytest.raises(bm.PlanError):
        bm.plan_moves([30] * 6, [25, 25], [25, 25, 30, 30, 30, 30])      # 빈 자리 없음
    with pytest.raises(bm.PlanError):
        bm.plan_moves([30] * 6, [None], [25, 30, 30, 30, 30, 30])        # 25mm 없음


def test_plan_replace():
    bed = [25, 30, 35, 25, 30, 35]
    rack = [30, None, 35, 30]
    moves, skipped = bm.plan_replace(bed, rack, [1, 3, 4])
    assert skipped == [3]                                              # 25mm 예비 없음
    assert [bm.move_text(m) for m in moves] == [
        '침대 2번 (30mm) → 버림', '보관대 1번 (30mm) → 침대 2번',
        '침대 5번 (30mm) → 버림', '보관대 4번 (30mm) → 침대 5번']
    end_bed, end_rack = simulate(bed, rack, moves)
    assert end_bed == bed and end_rack == [None, None, 35, None]


# ── 커버 원호 ──
DEMO_S = [575.41, -16.09, 117.92, 135.46, -179.99, 45.19]
DEMO_V = [566.00, -58.40, 249.02, 133.59, -179.99, 43.43]
DEMO_E = [566.00, -291.64, 345.38, 89.57, -142.37, 3.34]


def _path(grip, above=80.0, retreat=60.0):
    return bm.cover_path(DEMO_S, DEMO_V, DEMO_E, grip, DEMO_S[3:], above, retreat)


def test_zyz_matrix():
    """두산 ZYZ: B=180 이면 툴 Z 가 바로 아래, 회전행렬은 직교."""
    assert bm.tool_z([0, 0, 0, 30.0, 180.0, 10.0]) == pytest.approx([0, 0, -1], abs=1e-12)
    assert bm.tool_z([0, 0, 0, 0.0, 90.0, 0.0]) == pytest.approx([1, 0, 0], abs=1e-12)
    assert bm.tool_z([0, 0, 0, 90.0, 90.0, 0.0]) == pytest.approx([0, 1, 0], abs=1e-12)
    r = bm.zyz_matrix(*DEMO_E[3:])
    assert r @ r.T == pytest.approx(bm.np.eye(3), abs=1e-12)
    assert bm.tilt_deg(DEMO_S) == pytest.approx(0.0, abs=0.02)
    assert bm.tilt_deg(DEMO_E) == pytest.approx(180 - 142.37, abs=1e-9)


def test_circle_3pt():
    c, r, ax = bm.circle_3pt([10, 0, 5], [0, 10, 5], [-10, 0, 5])
    assert c == pytest.approx([0, 0, 5]) and r == pytest.approx(10) and ax == pytest.approx([0, 0, 1])
    with pytest.raises(ValueError):
        bm.circle_3pt([0, 0, 0], [1, 1, 1], [2, 2, 2])


def _ang(p, path):
    """경첩에서 본 고리 각도 [deg] (0 = 닫힘)."""
    _, yc, zc = path['hinge']
    return math.degrees(math.atan2(p[2] - zc, p[1] - yc))


def _dist(p, path):
    _, yc, zc = path['hinge']
    return math.hypot(p[1] - yc, p[2] - zc)


def test_hinge_from_demo():
    """경첩: 닫힌 고리 높이, 1/3/5번 줄(y -179) 바깥. 시작점과 경유점이 경첩에서 같은 거리."""
    yc, zc = bm.hinge_from_demo(DEMO_S, DEMO_V)
    assert zc == DEMO_S[2] and -250 < yc < -230
    assert math.hypot(DEMO_S[1] - yc, DEMO_S[2] - zc) == pytest.approx(math.hypot(DEMO_V[1] - yc, DEMO_V[2] - zc))


def test_cover_path_reproduces_demo():
    """데모 시작점을 잡으면 데모 경유점/끝점의 y, z 가 그대로 나와야 한다 (x 는 시작점 x 로 고정)."""
    p = _path(DEMO_S[:3])
    assert p['via'][1:3] == pytest.approx(DEMO_V[1:3], abs=1e-3) and p['via'][3:] == DEMO_V[3:]
    assert p['end'][1:3] == pytest.approx(DEMO_E[1:3], abs=1e-3) and p['end'][3:] == DEMO_E[3:]
    assert p['radius'] == pytest.approx(p['demo_radius'])


def test_cover_path_grip_at_y_minus_50():
    """y -50 에서 잡기: x 는 끝까지 그대로, 원호 3점은 경첩 둘레 같은 원, 끝점은 데모와 같은 각도/비율."""
    g = [576.28, -50.0, 117.92]
    p = _path(g)
    for k in ('above', 'grip', 'mid', 'via', 'end', 'rest', 'close_end'):
        assert p[k][0] == g[0]                                          # x 유지
    c, r, ax = bm.circle_3pt(p['grip'][:3], p['mid'][:3], p['via'][:3])
    assert c == pytest.approx(p['hinge'], abs=0.05) and abs(ax[0]) == pytest.approx(1.0)   # 좌표 0.001mm 반올림 영향
    assert r == pytest.approx(p['radius'], abs=0.05) and p['radius'] == pytest.approx(g[1] - p['hinge'][1])
    assert _ang(p['mid'], p) == pytest.approx(p['via_deg'] / 2, abs=1e-3)
    assert _ang(p['via'], p) == pytest.approx(_ang(DEMO_V, _path(DEMO_S[:3])), abs=1e-3)
    assert _ang(p['end'], p) == pytest.approx(p['end_deg'], abs=1e-3) and 92 < p['end_deg'] < 110
    assert _dist(p['end'], p) / p['radius'] == pytest.approx(p['end_reach'], abs=1e-4)
    assert _ang(p['rest'], p) == pytest.approx(110.0, abs=1e-3)
    assert _dist(p['rest'], p) == pytest.approx(p['radius'], abs=1e-3)
    assert bm.tilt_deg(p['grip']) < 0.1 and bm.tilt_deg(p['via']) < 0.1     # 원호 동안 툴은 거의 수직
    # 직선 구간(경유 → 끝): x 는 그대로, y 는 줄고 z 는 늘어난다
    assert p['end'][1] < p['via'][1] and p['end'][2] > p['via'][2]


def test_cover_path_approach_points():
    p = _path([576.28, -50.0, 117.92], above=80.0, retreat=60.0)
    assert p['above'] == pytest.approx(p['grip'][:2] + [p['grip'][2] + 80.0] + p['grip'][3:])
    for a, b in (('end', 'end_app'), ('rest', 'rest_app')):
        d = bm.np.array(p[a][:3]) - bm.np.array(p[b][:3])
        assert bm.np.linalg.norm(d) == pytest.approx(60.0, abs=0.01)
        assert d / 60.0 == pytest.approx(bm.tool_z(p[a]), abs=1e-4)      # 툴 Z 축을 따라 빠진다
        assert p[b][2] > p[a][2]


def test_cover_path_errors():
    with pytest.raises(ValueError):                                      # 순서가 바뀜
        bm.cover_path(DEMO_S, DEMO_E, DEMO_V, DEMO_S[:3], DEMO_S[3:], 80, 60)
    with pytest.raises(ValueError):                                      # 경첩 바로 옆
        _path([576.28, -230.0, 117.92])


def test_cover_path_hinge_safety_checks():
    """경첩 보호 검사: 가운데에서 벗어난 x, 틀린 고리 높이, 받침보다 더 젖히는 끝점은 거부."""
    g = [576.28, -50.0, 117.92]
    _path(g)                                                             # 기본값은 통과
    with pytest.raises(ValueError, match='가운데'):                      # x 20mm 벗어남 → 한쪽 경첩에 힘이 몰림
        _path([g[0] + 20.0, g[1], g[2]])
    with pytest.raises(ValueError, match='고리 높이'):                   # z 를 50mm 잘못 넣음
        _path([g[0], g[1], g[2] + 50.0])
    with pytest.raises(ValueError, match='받침'):                       # 받침(100도)보다 끝점이 더 열림
        bm.cover_path(DEMO_S, DEMO_V, DEMO_E, g, DEMO_S[3:], 80, 60, rest_deg=100.0)
    with pytest.raises(ValueError, match='떨어집니다'):                 # 끝점이 수직을 안 넘음
        bm.cover_path(DEMO_S, DEMO_V, DEMO_E, g, DEMO_S[3:], 80, 60, min_open_deg=105.0)


def test_cover_path_close_margin():
    """닫기 끝점은 완전히 닫히기 close_margin 도 전: 같은 원 위, 잡는 점보다 위."""
    p = bm.cover_path(DEMO_S, DEMO_V, DEMO_E, [576.28, -50.0, 117.92], DEMO_S[3:], 80, 60, close_margin_deg=2.0)
    assert _dist(p['close_end'], p) == pytest.approx(p['radius'], abs=1e-2)
    assert _ang(p['close_end'], p) == pytest.approx(2.0, abs=1e-2)
    assert p['close_end'][2] > p['grip'][2]
    assert abs(p['grip_angle']) < 1.0 and abs(p['off_axial']) < 1.0


def test_cover_path_line_segments():
    """직선 구간을 나누면 중간점은 경첩 원 근처, 각도는 고르게, x 고정. 1 이면 [end] 하나."""
    g = [576.28, -50.0, 117.92]
    assert bm.cover_path(DEMO_S, DEMO_V, DEMO_E, g, DEMO_S[3:], 80, 60, line_segments=1)['line'] == \
        [_path(g)['end']]
    p = bm.cover_path(DEMO_S, DEMO_V, DEMO_E, g, DEMO_S[3:], 80, 60, line_segments=3)
    assert len(p['line']) == 3 and p['line'][-1] == p['end']
    angs = [p['via_deg']] + [_ang(q, p) for q in p['line']]
    steps = [b - a for a, b in zip(angs, angs[1:])]
    assert steps == pytest.approx([steps[0]] * 3, abs=1e-3)
    for q in p['line']:
        assert q[0] == g[0] and p['radius'] - 0.01 <= _dist(q, p) <= p['radius'] * p['end_reach'] + 0.01
