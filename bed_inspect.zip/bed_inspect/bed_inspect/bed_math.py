# 계산만 하는 함수 모음 (로봇, ROS 와 무관 → 로봇 없이 테스트 가능)
#
#   fit_stiffness   누르기 곡선(높이, 힘) → 강성 k, 표면 높이
#   judge           블록별 강성 → 정상 / 주의 / 불량
#   measured_tilt   6개 표면 높이 → 침대 기울기
#   plan_tilt       목표 기울기 → 3가지 높이로 만들 수 있는 가장 가까운 배치
#   plan_moves      현재 배치 → 목표 배치로 가는 블록 이동 순서
#   plan_replace    불량 블록 → 같은 높이 예비 블록으로 바꾸는 이동 순서
#   cover_path      데모 원호 3점 + 고리 잡는 점 → 커버 열기 movec 좌표 (경첩 축 기준 회전)
#
# 칸 번호는 0부터 센다(코드 안). 화면에 보여줄 때만 +1 한다.

import itertools
import math
import statistics
from collections import Counter

import numpy as np


class PlanError(Exception):
    """교체 계획을 세울 수 없음 (재고 부족, 보관대 빈 자리 없음 등)."""


# ── 강성 ──────────────────────────────────────────────────────────────
def fit_stiffness(curve, f_min, min_points=4):
    """누르기 곡선 [(z, 힘), ...] 을 직선 F = k * (z_surf - z) 로 맞춘다.

    f_min 이상인 점만 쓴다(천이 늘어나는 초반 구간 제외).
    반환: {'k': N/mm, 'z_surf': 힘이 0 이 되는 높이(=표면 높이), 'r2': 맞춤 품질, 'n': 점 수}
          점이 모자라거나 직선이 아니면 None
    """
    pts = [(z, f) for z, f in curve if f >= f_min]
    if len(pts) < min_points:
        return None
    z = np.array([p[0] for p in pts], dtype=float)
    f = np.array([p[1] for p in pts], dtype=float)
    if z.max() - z.min() < 1e-6:
        return None
    slope, intercept = np.polyfit(z, f, 1)      # f = slope * z + intercept
    k = -slope                                   # 내려갈수록(z 감소) 힘이 커진다
    if k <= 1e-6:
        return None
    pred = slope * z + intercept
    ss_res = float(((f - pred) ** 2).sum())
    ss_tot = float(((f - f.mean()) ** 2).sum())
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return {'k': float(k), 'z_surf': float(intercept / k), 'r2': float(r2), 'n': len(pts)}


# ── 불량 판정 ─────────────────────────────────────────────────────────
def judge(blocks, calib, warn_ratio, fail_ratio):
    """블록별 판정을 blocks 의 각 dict 에 채운다 (ref, ref_src, dev, grade).

    blocks: [{'height': mm, 'k': N/mm 또는 None, 'error': None|'no_contact'|'too_deep'|...}, ...]
    calib : {높이: 기준 강성} (기준값 저장을 한 경우). 없는 높이는 아래 방법으로 대신한다.

    기준 강성 정하는 법
      1) calib 에 그 높이가 있으면 그 값
      2) 없으면 이번에 잰 블록들의 (k × 높이) 중앙값 ÷ 높이
         (같은 재질, 같은 단면이면 k × 높이 가 일정하다는 성질을 이용.
          높이가 전부 같으면 그냥 "k 의 중앙값"과 같다)
    grade: 'ok' 정상 / 'warn' 주의 / 'fail' 불량 / 'nodata' 측정 실패(다시 측정 필요)
    """
    kh = [b['k'] * b['height'] for b in blocks if b.get('k') is not None]
    kh_med = statistics.median(kh) if kh else None
    for b in blocks:
        b['ref'] = b['ref_src'] = b['dev'] = None
        if b.get('error') in ('no_contact', 'too_deep'):
            b['grade'] = 'fail'          # 블록이 없거나 너무 물러서 바닥까지 들어감
            continue
        if b.get('k') is None:
            b['grade'] = 'nodata'
            continue
        ref = _calib_get(calib, b['height'])
        src = 'calib'
        if ref is None and kh_med is not None:
            ref, src = kh_med / b['height'], 'median'
        if ref is None or ref <= 0:
            b['grade'] = 'nodata'
            continue
        dev = (b['k'] - ref) / ref
        b['ref'], b['ref_src'], b['dev'] = float(ref), src, float(dev)
        b['grade'] = 'fail' if abs(dev) >= fail_ratio else 'warn' if abs(dev) >= warn_ratio else 'ok'
    return blocks


def _calib_get(calib, height):
    if not calib:
        return None
    for h, k in calib.items():
        if abs(float(h) - float(height)) < 1e-6:
            return float(k)
    return None


def make_calib(blocks, old=None):
    """측정 결과에서 높이별 기준 강성(중앙값)을 만든다. old 에 있던 다른 높이는 유지."""
    out = {str(float(h)): float(k) for h, k in (old or {}).items()}
    by_h = {}
    for b in blocks:
        if b.get('k') is not None:
            by_h.setdefault(float(b['height']), []).append(b['k'])
    for h, ks in by_h.items():
        out[str(h)] = float(statistics.median(ks))
    return out


# ── 기울기 ────────────────────────────────────────────────────────────
def fit_plane(xy, z):
    """점들을 평면 z = a*x + b*y + c 로 맞춘다. 반환 (a, b, c, rms 오차)."""
    A = np.array([[x, y, 1.0] for x, y in xy], dtype=float)
    zz = np.array(z, dtype=float)
    coef, *_ = np.linalg.lstsq(A, zz, rcond=None)
    res = zz - A @ coef
    return float(coef[0]), float(coef[1]), float(coef[2]), float(math.sqrt((res ** 2).mean()))


def bed_axes(xy, rows, cols):
    """칸 중심 좌표에서 침대의 열 방향(1→3번), 행 방향(1→4번) 단위벡터와 칸 간격을 구한다."""
    p = np.array(xy, dtype=float).reshape(rows, cols, 2)
    dc = [p[r, c + 1] - p[r, c] for r in range(rows) for c in range(cols - 1)]
    dr = [p[r + 1, c] - p[r, c] for r in range(rows - 1) for c in range(cols)]
    out = {}
    for name, d in (('col', dc), ('row', dr)):
        if not d:
            out[name] = (np.array([0.0, 0.0]), 0.0)
            continue
        m = np.mean(d, axis=0)
        n = float(np.linalg.norm(m))
        out[name] = (m / n if n > 1e-9 else np.array([0.0, 0.0]), n)
    return {'u_col': out['col'][0], 'pitch_col': out['col'][1],
            'u_row': out['row'][0], 'pitch_row': out['row'][1]}


def measured_tilt(xy, z, rows, cols):
    """잰 표면 높이로 침대 기울기를 구한다.

    xy: 6칸 중심 좌표(베이스 기준), z: 칸별 표면 높이 (None = 측정 실패 → 빼고 계산)
    반환 {'col_deg': 열 방향 기울기(+ 면 3번 쪽이 높음), 'row_deg': 행 방향(+ 면 4번 쪽이 높음),
          'rms': 평면에서 벗어난 정도 mm, 'n': 사용한 점 수}  /  점이 모자라면 None
    """
    ax = bed_axes(xy, rows, cols)
    use = [(p, v) for p, v in zip(xy, z) if v is not None]
    if len(use) < 3:
        return None
    a, b, _, rms = fit_plane([p for p, _ in use], [v for _, v in use])
    grad = np.array([a, b])
    return {'col_deg': math.degrees(math.atan(float(grad @ ax['u_col']))),
            'row_deg': math.degrees(math.atan(float(grad @ ax['u_row']))),
            'rms': rms, 'n': len(use)}


def nominal_tilt(heights, rows, cols, pitch_col, pitch_row):
    """블록 높이 배치(공칭값)로 만들어지는 기울기. 반환 (col_deg, row_deg, rms)."""
    xy = [(c * pitch_col, r * pitch_row) for r in range(rows) for c in range(cols)]
    a, b, _, rms = fit_plane(xy, heights)
    return math.degrees(math.atan(a)), math.degrees(math.atan(b)), rms


def tilt_candidates(bed, rack, heights, rows, cols, pitch_col, pitch_row,
                    allow_step=False, plane_tol=0.5):
    """지금 가진 블록(침대 + 보관대)으로 만들 수 있는 모든 배치와 그 기울기.

    3가지 높이 × 6칸 = 729가지를 전부 계산한다(순식간).
    allow_step=False 면 윗면이 한 평면에 놓이는 배치만 남긴다.
    """
    n = rows * cols
    have = Counter(h for h in list(bed) + list(rack) if h is not None)
    out = []
    for combo in itertools.product(heights, repeat=n):
        need = Counter(combo)
        if any(need[h] > have.get(h, 0) for h in need):
            continue                                    # 블록 개수가 모자람
        col_deg, row_deg, rms = nominal_tilt(combo, rows, cols, pitch_col, pitch_row)
        if not allow_step and rms > plane_tol:
            continue
        out.append({'heights': list(combo), 'col_deg': col_deg, 'row_deg': row_deg, 'rms': rms})
    return out


def achievable_angles(cands):
    """화면에 보여줄 "가능한 각도" 목록. {'col': [...], 'row': [...]} (다른 축은 0 인 것만)."""
    col = sorted({round(c['col_deg'], 1) + 0.0 for c in cands if abs(c['row_deg']) < 0.05})
    row = sorted({round(c['row_deg'], 1) + 0.0 for c in cands if abs(c['col_deg']) < 0.05})
    return {'col': col, 'row': row}


def plan_tilt(target_col, target_row, bed, rack, heights, rows, cols, pitch_col, pitch_row,
              allow_step=False, plane_tol=0.5):
    """목표 기울기에 가장 가까운 배치와, 거기까지 가는 블록 이동 순서를 구한다.

    고르는 순서: ① 목표 각도와 차이가 가장 작은 것 ② 윗면이 더 평평한 것
                ③ 옮기는 블록 수가 적은 것 ④ 평균 높이 변화가 작은 것
    반환 {'heights', 'col_deg', 'row_deg', 'rms', 'err', 'changed': 바뀌는 칸 수, 'moves'}
    """
    cands = tilt_candidates(bed, rack, heights, rows, cols, pitch_col, pitch_row,
                            allow_step, plane_tol)
    if not cands:
        raise PlanError('지금 가진 블록으로 만들 수 있는 배치가 없습니다.')
    cur_mean = statistics.mean([h for h in bed if h is not None] or [0.0])

    def key(c):
        err = math.hypot(c['col_deg'] - target_col, c['row_deg'] - target_row)
        changed = sum(1 for a, b in zip(bed, c['heights']) if a != b)
        return (round(err, 3), round(c['rms'], 3), changed,
                round(abs(statistics.mean(c['heights']) - cur_mean), 3))

    last_err = None
    for c in sorted(cands, key=key):
        try:
            moves = plan_moves(bed, rack, c['heights'])
        except PlanError as e:
            last_err = e                                # 이 배치는 옮길 방법이 없음 → 다음 후보
            continue
        k = key(c)
        return dict(c, err=k[0], changed=k[2], moves=moves)
    raise PlanError(str(last_err))


# ── 블록 이동 순서 ────────────────────────────────────────────────────
def plan_moves(bed, rack, target):
    """침대 배치 bed 를 target 으로 바꾸는 이동 순서.

    이동 하나 = {'src': ('bed'|'rack', 번호), 'dst': ('bed'|'rack', 번호), 'h': 높이}
    규칙: 빈 칸이 생기면 바로 채운다(보관대에서, 없으면 자리가 틀린 다른 칸에서 직접).
          채울 수 있는 빈 칸이 없으면 자리가 틀린 블록 하나를 보관대 빈 자리로 뺀다.
    그래서 보관대에는 빈 자리가 1개만 있으면 된다.
    """
    bed, rack, target = list(bed), list(rack), list(target)
    n = len(bed)
    moves = []

    def wrong(i):
        return bed[i] != target[i]

    def find(seq, pred):
        return next((i for i, v in enumerate(seq) if pred(i, v)), None)

    for _ in range(4 * n + 4):
        if not any(wrong(i) for i in range(n)):
            return moves
        moved = False
        for i in range(n):                              # 1) 빈 칸 채우기
            if bed[i] is not None or target[i] is None:
                continue
            j = find(rack, lambda _, v: v == target[i])
            if j is not None:
                moves.append({'src': ('rack', j), 'dst': ('bed', i), 'h': rack[j]})
                bed[i], rack[j] = rack[j], None
                moved = True
                break
            s = find(bed, lambda s, v: s != i and v == target[i] and wrong(s))
            if s is not None:
                moves.append({'src': ('bed', s), 'dst': ('bed', i), 'h': bed[s]})
                bed[i], bed[s] = bed[s], None
                moved = True
                break
        if moved:
            continue
        cand = [i for i in range(n) if bed[i] is not None and wrong(i)]   # 2) 틀린 블록 빼기
        if not cand:
            raise PlanError('필요한 높이의 블록이 모자랍니다.')
        e = find(rack, lambda _, v: v is None)
        if e is None:
            raise PlanError('보관대에 빈 자리가 없어서 블록을 뺄 수 없습니다. 한 자리를 비워 주세요.')
        cand.sort(key=lambda i: 0 if target[i] in rack else 1)   # 빼면 바로 채울 수 있는 칸 먼저
        i = cand[0]
        moves.append({'src': ('bed', i), 'dst': ('rack', e), 'h': bed[i]})
        rack[e], bed[i] = bed[i], None
    raise PlanError('이동 순서를 만들지 못했습니다.')


def plan_replace(bed, rack, faulty):
    """불량 칸(faulty, 0부터)의 블록을 버리고 같은 높이 예비 블록을 넣는 이동 순서.

    반환 (moves, skipped): 같은 높이 예비가 없는 칸은 건드리지 않고 skipped 에 넣는다.
    """
    rack = list(rack)
    moves, skipped = [], []
    for i in faulty:
        h = bed[i]
        j = next((j for j, v in enumerate(rack) if v is not None and v == h), None)
        if j is None:
            skipped.append(i)
            continue
        moves.append({'src': ('bed', i), 'dst': ('discard', 0), 'h': h})
        moves.append({'src': ('rack', j), 'dst': ('bed', i), 'h': h})
        rack[j] = None
    return moves, skipped


def apply_move(bed, rack, mv):
    """이동 하나를 재고(bed, rack 리스트)에 반영한다."""
    (sk, si), (dk, di) = mv['src'], mv['dst']
    src = bed if sk == 'bed' else rack
    h = src[si]
    src[si] = None
    if dk == 'bed':
        bed[di] = h
    elif dk == 'rack':
        rack[di] = h
    return h


def move_text(mv):
    """이동 하나를 사람이 읽는 문장으로."""
    names = {'bed': '침대 %d번', 'rack': '보관대 %d번'}
    (sk, si), (dk, di) = mv['src'], mv['dst']
    src = names[sk] % (si + 1)
    dst = '버림' if dk == 'discard' else names[dk] % (di + 1)
    return f'{src} ({mv["h"]:g}mm) → {dst}'


# ── 커버 원호 (movec) ─────────────────────────────────────────────────
# 좌표 표기는 두산 posx 와 같다: [x, y, z, A, B, C] (mm, deg), 자세는 ZYZ 오일러각.

def zyz_matrix(a, b, c):
    """두산 posx 자세 (A, B, C) [deg] → 3x3 회전행렬 (Rz(A)·Ry(B)·Rz(C)). 3번째 열이 툴 Z축."""
    a, b, c = (math.radians(v) for v in (a, b, c))
    ca, sa, cb, sb, cc, sc = math.cos(a), math.sin(a), math.cos(b), math.sin(b), math.cos(c), math.sin(c)
    rz = lambda c_, s_: np.array([[c_, -s_, 0.0], [s_, c_, 0.0], [0.0, 0.0, 1.0]])   # noqa: E731
    ry = np.array([[cb, 0.0, sb], [0.0, 1.0, 0.0], [-sb, 0.0, cb]])
    return rz(ca, sa) @ ry @ rz(cc, sc)


def tool_z(pose):
    """posx 의 툴 Z축(그리퍼가 향하는 방향) 단위벡터, 베이스 기준."""
    return zyz_matrix(*pose[3:6])[:, 2]


def tilt_deg(pose):
    """툴 Z축이 '바로 아래(-Z)'에서 몇 도 기울었는지."""
    return math.degrees(math.acos(max(-1.0, min(1.0, -tool_z(pose)[2]))))


def circle_3pt(p1, p2, p3):
    """세 점을 지나는 원 → (중심, 반지름, 회전축 단위벡터). 축 방향은 p1→p2 로 도는 쪽이 + (오른손 법칙)."""
    p1, p2, p3 = (np.asarray(p, dtype=float) for p in (p1, p2, p3))
    a, b = p1 - p3, p2 - p3
    axb = np.cross(a, b)
    nn = float(axb @ axb)
    if nn < 1e-6 * float(a @ a) * float(b @ b):
        raise ValueError('원호 세 점이 한 직선 위에 있습니다 (원이 정해지지 않음).')
    center = p3 + np.cross(float(a @ a) * b - float(b @ b) * a, axb) / (2.0 * nn)
    axis = np.cross(p1 - center, p2 - center)
    axis = axis / np.linalg.norm(axis)
    return center, float(np.linalg.norm(p1 - center)), axis


def _angle_about(axis, u, v):
    """축 axis 를 기준으로 u → v 로 돈 각도 [deg], 0~360."""
    return math.degrees(math.atan2(float(axis @ np.cross(u, v)), float(u @ v))) % 360.0


def rotate_about(p, center, axis, deg):
    """점 p 를 (center 를 지나는 axis 축) 둘레로 deg 만큼 돌린다 (로드리게스 공식)."""
    v = np.asarray(p, dtype=float) - center
    t = math.radians(deg)
    k = axis
    return center + v * math.cos(t) + np.cross(k, v) * math.sin(t) + k * float(k @ v) * (1.0 - math.cos(t))


def hinge_from_demo(demo_start, demo_via):
    """데모 시작점(뚜껑 닫힘)과 경유점(원호 끝)으로 경첩 위치 (y, z) 를 구한다. 경첩 축은 베이스 X 방향.

    가정: 닫힌 뚜껑은 수평이고 경첩은 고리와 같은 높이에 있다 → 경첩 z = 시작점 z.
          시작점과 경유점은 경첩에서 같은 거리(원 위) → 경첩 y 는 두 점의 수직이등분선과 z=시작점z 의 교점.
    """
    ys, zs = float(demo_start[1]), float(demo_start[2])
    yv, zv = float(demo_via[1]), float(demo_via[2])
    if abs(ys - yv) < 1.0:
        raise ValueError('데모 시작점과 경유점의 y 가 같아 경첩을 정할 수 없습니다.')
    h = zv - zs
    yc = (ys * ys - yv * yv - h * h) / (2.0 * (ys - yv))
    return yc, zs


def _lid_angle(y, z, yc, zc):
    """경첩에서 본 고리 각도 [deg]: 0 = 닫힘(고리가 +y 쪽 수평), 90 = 수직, 90 넘으면 경첩 너머로 넘어감."""
    return math.degrees(math.atan2(z - zc, y - yc))


def cover_path(demo_start, demo_via, demo_end, grip_xyz, grip_ori, above_dz, retreat,
               rest_deg=110.0, line_segments=1, close_margin_deg=0.0, min_open_deg=92.0, max_axial_offset=15.0,
               max_grip_angle=10.0, min_radius=50.0):
    """커버 열기/닫기 좌표를 만든다 (데모 방식: 원호 + y·z 직선).

    데모 동작: 고리를 수직으로 내려가 잡고 → 시작점에서 경유점까지 원호(movec) → 경유점에서 끝점까지
              x 는 그대로 두고 y, z 만 바꾸는 직선 이동 → 놓으면 뚜껑이 베드 옆 받침(약 110도)에 걸친다.
    경첩: hinge_from_demo (시작점과 경유점이 같은 원 위, 경첩은 닫힌 고리와 같은 높이). 축은 베이스 X.
    고리를 다른 곳(grip_xyz, 보통 y 가 다름)에서 잡으면 같은 경첩 둘레로 반지름만 바뀐다:
      경유점 = 같은 각도(원 위),  끝점 = 데모 끝점과 같은 각도 + 같은 비율의 거리(데모에서 원보다 조금 밖으로 당긴 만큼).
    x 는 처음부터 끝까지 grip_xyz 의 x 그대로.
    자세: 잡을 때 grip_ori(수직), 경유점/끝점은 데모 자세, 원호 중간점은 잡는 자세와 경유 자세의 중간.

    경첩 보호용 검사 (어기면 ValueError):
      - x 가 데모 시작점(경첩 두 개의 가운데)에서 max_axial_offset 넘게 벗어나면 거부
      - 잡는 점이 닫힌 뚜껑 높이에서 max_grip_angle 넘게 벗어나면 거부 (고리 높이 오입력)
      - 끝점 각도는 min_open_deg 이상(수직을 넘겨야 놓았을 때 받침 쪽으로 넘어감), rest_deg 미만(받침을 밀지 않음)

    돌려주는 dict (좌표는 posx 6개 리스트):
      above, grip   잡기 전 수직 위 / 잡는 자세 (원호 시작)
      mid, via      원호 중간점(movec 의 첫 점) / 원호 끝 = 직선 시작
      line          경유점 → 끝점 직선 구간의 목표점 목록 (마지막이 end). line_segments=1 이면 [end] (데모처럼 한 번에).
                    n 개로 나누면 경첩 둘레를 따라가는 n 개의 짧은 직선 (각도/거리/자세를 고르게 나눔, x 고정).
                    한 번에 가면 직선이 원 안쪽으로 파고든다 (반지름 190mm, 67도 구간이면 가운데에서 약 32mm).
      end           직선 끝 = 놓는 자리
      end_app       end 에서 툴 -Z 로 retreat 만큼 뺀 자리 (놓고 빠질 때)
      rest          놓은 뒤 뚜껑이 받침(rest_deg)에 걸쳤을 때의 고리 자리 (닫을 때 잡는 곳, 자세는 끝점 자세)
      rest_app      rest 에서 툴 -Z 로 retreat 만큼 뺀 자리 (닫을 때 들어가는 곳)
      close_end     닫기 원호 끝: 완전히 닫히기 close_margin_deg 전
      확인용: hinge [x, y, z], radius, via_deg, end_deg, rest_deg, end_reach, off_axial, grip_angle, end_tilt_deg
    """
    yc, zc = hinge_from_demo(demo_start, demo_via)
    r_demo = math.hypot(demo_start[1] - yc, demo_start[2] - zc)
    via_deg = _lid_angle(demo_via[1], demo_via[2], yc, zc)
    end_deg = _lid_angle(demo_end[1], demo_end[2], yc, zc)
    end_reach = math.hypot(demo_end[1] - yc, demo_end[2] - zc) / r_demo
    if not 5.0 < via_deg < end_deg:
        raise ValueError(f'데모 좌표 순서가 이상합니다 (경유 {via_deg:.1f}도, 끝 {end_deg:.1f}도).')
    if end_deg < min_open_deg:
        raise ValueError(f'끝점 각도 {end_deg:.1f}도가 {min_open_deg:.0f}도보다 작습니다. '
                         '수직을 넘지 않고 놓으면 뚜껑이 닫히며 떨어집니다.')
    if end_deg >= rest_deg:
        raise ValueError(f'끝점 각도 {end_deg:.1f}도가 받침 각도 {rest_deg:.0f}도 이상입니다. 로봇이 받침을 밀게 됩니다.')
    if not 0.0 <= close_margin_deg < via_deg:
        raise ValueError(f'닫기 여유 각도 {close_margin_deg}도가 이상합니다 (0 이상, 경유 {via_deg:.1f}도 미만).')

    gx, gy, gz = (float(v) for v in grip_xyz)
    off_axial = gx - float(demo_start[0])
    if abs(off_axial) > max_axial_offset:
        raise ValueError(f'잡는 점 x 가 경첩 두 개의 가운데(데모 시작점 x {demo_start[0]})에서 {off_axial:+.1f}mm '
                         f'벗어났습니다 (허용 ±{max_axial_offset:.0f}mm). 한쪽 경첩에 힘이 몰립니다.')
    grip_angle = _lid_angle(gy, gz, yc, zc)
    if abs(grip_angle) > max_grip_angle:
        raise ValueError(f'잡는 점이 닫힌 뚜껑 면에서 {grip_angle:+.1f}도 벗어났습니다 (허용 ±{max_grip_angle:.0f}도). '
                         '고리 높이(z)를 확인하세요.')
    r = math.hypot(gy - yc, gz - zc)
    if r < min_radius:
        raise ValueError(f'잡는 점이 경첩에 너무 가깝습니다 (반지름 {r:.1f}mm < {min_radius:.0f}mm).')

    def at(deg, reach=1.0):
        t = math.radians(deg)
        return [gx, yc + r * reach * math.cos(t), zc + r * reach * math.sin(t)]

    def pose(xyz, ori):
        return [round(float(v), 3) for v in xyz] + [float(o) for o in ori]

    def back(p):
        return pose(np.asarray(p[:3]) - tool_z(p) * retreat, p[3:6])

    if int(line_segments) < 1:
        raise ValueError('line_segments 는 1 이상이어야 합니다.')
    mid_ori = [(a + b) / 2.0 for a, b in zip(grip_ori, demo_via[3:6])]
    grip = pose([gx, gy, gz], grip_ori)
    end = pose(at(end_deg, end_reach), demo_end[3:6])
    rest = pose(at(rest_deg), demo_end[3:6])
    n = int(line_segments)
    line = []
    for i in range(1, n):
        t = i / n
        ori = [a + (b - a) * t for a, b in zip(demo_via[3:6], demo_end[3:6])]
        line.append(pose(at(via_deg + (end_deg - via_deg) * t, 1.0 + (end_reach - 1.0) * t), ori))
    line.append(end)
    return {
        'above': pose([gx, gy, gz + above_dz], grip_ori), 'grip': grip,
        'mid': pose(at((grip_angle + via_deg) / 2.0), mid_ori), 'via': pose(at(via_deg), demo_via[3:6]),
        'line': line, 'end': end, 'end_app': back(end), 'rest': rest, 'rest_app': back(rest),
        'close_end': pose(at(grip_angle + close_margin_deg), grip_ori),
        'hinge': [gx, yc, zc], 'radius': r, 'demo_radius': r_demo, 'via_deg': via_deg, 'end_deg': end_deg,
        'rest_deg': float(rest_deg), 'close_deg': float(close_margin_deg), 'end_reach': end_reach,
        'off_axial': off_axial, 'grip_angle': grip_angle, 'end_tilt_deg': tilt_deg(end),
    }
